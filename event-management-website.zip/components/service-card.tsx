import Image from "next/image"
import { MessageCircle } from "lucide-react"

interface ServiceCardProps {
  title: string
  description: string
  image: string
  whatsappMessage: string
}

export function ServiceCard({
  title,
  description,
  image,
  whatsappMessage,
}: ServiceCardProps) {
  const whatsappUrl = `https://wa.me/919999999999?text=${encodeURIComponent(whatsappMessage)}`

  return (
    <article className="bg-card rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
      <div className="relative h-52">
        <Image
          src={image}
          alt={title}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
      </div>
      <div className="p-4">
        <h3 className="text-xl font-semibold text-secondary">{title}</h3>
        <p className="mt-2 text-muted-foreground">{description}</p>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 mt-4 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-5 py-2.5 rounded-md transition-colors"
        >
          <MessageCircle className="w-5 h-5" />
          WhatsApp Enquiry
        </a>
      </div>
    </article>
  )
}
