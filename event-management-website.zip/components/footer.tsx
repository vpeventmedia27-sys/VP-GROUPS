import { Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-foreground text-card py-8 px-4 text-center">
      <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
      <p className="flex items-center justify-center gap-2">
        <Mail className="w-5 h-5" />
        <a
          href="mailto:vpeventandmanagement@gmail.com"
          className="text-accent hover:underline"
        >
          vpeventandmanagement@gmail.com
        </a>
      </p>
      <p className="mt-6 text-card/70">
        &copy; {new Date().getFullYear()} VP EVENTS AND MANAGEMENT
      </p>
    </footer>
  )
}
