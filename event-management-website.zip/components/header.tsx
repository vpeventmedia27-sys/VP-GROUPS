import Image from "next/image"

export function Header() {
  return (
    <header className="bg-gradient-to-br from-primary to-secondary text-primary-foreground text-center py-6 px-4">
      <div className="flex justify-center mb-4">
        <div className="bg-card rounded-lg p-1.5">
          <Image
            src="https://i.ibb.co/VWdrcdnQ/vp-event-logo-2.jpg"
            alt="VP Events Logo"
            width={120}
            height={120}
            className="rounded-lg"
          />
        </div>
      </div>
      <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
        VP EVENTS AND MANAGEMENT
      </h1>
      <p className="mt-2 text-lg text-primary-foreground/90">
        Your Complete Event Solution
      </p>
    </header>
  )
}
