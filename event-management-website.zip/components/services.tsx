import { ServiceCard } from "./service-card"

const services = [
  {
    title: "Decorations",
    description: "Beautiful event and wedding decorations.",
    image:
      "https://images.unsplash.com/photo-1469371670807-013ccf25f16a?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Decoration service",
  },
  {
    title: "DJ Music",
    description: "Professional DJ and sound systems.",
    image:
      "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need DJ Music service",
  },
  {
    title: "Wedding Photography",
    description: "Capture your special moments forever.",
    image:
      "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Wedding Photography",
  },
  {
    title: "Catering",
    description: "Delicious food for all events.",
    image:
      "https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Catering service",
  },
  {
    title: "Videography",
    description: "Professional event videography services.",
    image:
      "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Videography",
  },
  {
    title: "Birthday Parties",
    description: "Fun and memorable birthday celebrations.",
    image:
      "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Birthday Party service",
  },
  {
    title: "Chenda Melam",
    description: "Traditional Kerala Chenda Melam performances.",
    image:
      "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Chenda Melam",
  },
  {
    title: "Bouncers",
    description: "Professional security and crowd management.",
    image:
      "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Bouncers",
  },
  {
    title: "Transportation",
    description: "Comfortable transport arrangements.",
    image:
      "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Transportation",
  },
  {
    title: "Return Gifts",
    description: "Special gifts for your guests.",
    image:
      "https://images.unsplash.com/photo-1512909006721-3d6018887383?auto=format&fit=crop&w=800&q=80",
    whatsappMessage: "I need Return Gifts",
  },
]

export function Services() {
  return (
    <section className="py-16 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-10">
          Our Services
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <ServiceCard key={service.title} {...service} />
          ))}
        </div>
      </div>
    </section>
  )
}
