export function Hero() {
  return (
    <section
      className="h-[400px] md:h-[500px] bg-cover bg-center flex items-center justify-center relative"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1500&q=80')",
      }}
    >
      <div className="absolute inset-0 bg-foreground/60" />
      <div className="relative z-10 bg-foreground/70 px-8 py-10 rounded-xl text-center max-w-2xl mx-4">
        <h2 className="text-3xl md:text-5xl font-bold text-card text-balance">
          Creating Memorable Events
        </h2>
        <p className="mt-4 text-lg md:text-xl text-card/90">
          Weddings, Birthdays, DJ Nights, Catering &amp; More
        </p>
      </div>
    </section>
  )
}
