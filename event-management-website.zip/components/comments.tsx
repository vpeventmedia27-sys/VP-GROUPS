"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export function Comments() {
  const [comment, setComment] = useState("")
  const [comments, setComments] = useState<string[]>([])

  const handleSubmit = () => {
    if (!comment.trim()) {
      alert("Please enter a comment")
      return
    }
    setComments((prev) => [...prev, comment])
    setComment("")
  }

  return (
    <section className="py-16 px-4 bg-card">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-3xl font-bold text-center text-primary mb-8">
          Customer Comments
        </h2>
        <div className="space-y-4">
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Write your comment here..."
            className="w-full h-32 p-4 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none bg-background text-foreground"
          />
          <Button
            onClick={handleSubmit}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            Post Comment
          </Button>
          <div className="space-y-3 mt-6">
            {comments.map((c, i) => (
              <div key={i} className="bg-muted p-4 rounded-lg text-foreground">
                {c}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
